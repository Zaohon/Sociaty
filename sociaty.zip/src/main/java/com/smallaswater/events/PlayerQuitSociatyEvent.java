package com.smallaswater.events;


import cn.nukkit.event.Event;

public class PlayerQuitSociatyEvent extends Event {
}
