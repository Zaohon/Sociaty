package com.smallaswater.events;


import cn.nukkit.event.Event;
import com.smallaswater.players.PlayerClass;
import com.smallaswater.sociaty.Sociaty;

/**
 * @author Administrator
 */
public class PlayerJoinSociatyEvent extends Event {

    private PlayerClass playerClass;
    private Sociaty sociaty;
    public PlayerJoinSociatyEvent(PlayerClass playerClass, Sociaty sociaty){
        this.playerClass = playerClass;
        this.sociaty = sociaty;
    }

    public Sociaty getSociaty() {
        return sociaty;
    }

    public PlayerClass getPlayerClass() {
        return playerClass;
    }
}
