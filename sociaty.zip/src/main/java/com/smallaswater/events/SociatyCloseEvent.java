package com.smallaswater.events;

import cn.nukkit.event.Event;


public class SociatyCloseEvent extends Event {

    public SociatyCloseEvent() {

    }
}
