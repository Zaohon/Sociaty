package com.smallaswater.events;

import cn.nukkit.event.Event;


public class SociatyCreateEvent extends Event {

    public SociatyCreateEvent() {

    }
}
