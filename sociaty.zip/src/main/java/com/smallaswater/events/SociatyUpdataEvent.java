package com.smallaswater.events;

import cn.nukkit.event.Event;

public class SociatyUpdataEvent extends Event {
}
