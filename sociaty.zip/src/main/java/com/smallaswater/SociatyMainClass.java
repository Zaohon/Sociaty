package com.smallaswater;

import cn.nukkit.plugin.PluginBase;
import com.smallaswater.sociaty.Sociaty;

import java.util.LinkedHashMap;

public class SociatyMainClass extends PluginBase {

    public LinkedHashMap<String, Sociaty> sociatys = new LinkedHashMap<>();


    @Override
    public void onEnable() {
        this.getLogger().info("公会加载成功");
        this.getLogger().info("初始化中....");


    }
}
