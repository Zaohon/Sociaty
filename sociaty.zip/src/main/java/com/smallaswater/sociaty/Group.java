package com.smallaswater.sociaty;

/**
 * @author Administrator
 */
public class Group {

    private int level;

    private Power name;

    public final static int DEFAULT_LEVEL = 0;

    public Group(Power name){
        this.name = name;
        this.level = DEFAULT_LEVEL;
    }


    public Group(Power name, int level){
        this.name = name;
        this.level = level;
    }

    public static Power getPowerByName(String name){
        for(Power power:Power.values()){
            if(power.getName().equals(name)){
                return power;
            }
        }
        return null;
    }

    public int getLevel() {
        return level;
    }

    public Power getName() {
        return name;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public void setName(Power name) {
        this.name = name;
    }
}
